/*  Auth constants   */
export const TOKEN_VERIFIED = 'TOKEN_VERIFIED';



/*  order constants   */