import InspectorDashboardPage from '../components/inspectorDashboard/InspectorDashboardPage.jsx';


export default InspectorDashboardPage;