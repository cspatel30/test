import ManageMainPage from '../components/manageEnquries/ManageMainPage.jsx';


export default ManageMainPage;