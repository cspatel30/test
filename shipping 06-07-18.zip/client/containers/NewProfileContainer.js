import NewProfilePage from '../components/newProfile/NewProfilePage.jsx';


export default NewProfilePage;