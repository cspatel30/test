import OrdersMainPage from '../components/orders/OrdersMainPage.jsx';


export default OrdersMainPage;