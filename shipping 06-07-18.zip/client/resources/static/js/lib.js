require ('jquery/dist/jquery.min.js');
require('hammerjs/hammer.min.js');
require('../resources/static/js/materialize.min.js');