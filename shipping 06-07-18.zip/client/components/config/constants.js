module.exports.apiConfig = {
  url: 'http://sis-beta.us-east-1.elasticbeanstalk.com'
};