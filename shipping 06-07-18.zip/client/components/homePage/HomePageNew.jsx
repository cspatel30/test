import React, { Component } from 'react';
import InspectionQuote from './InspectionQuote';

export default class HomePageNew extends Component {

  render() {
    return (
      <div>
        <InspectionQuote />
      </div> 
    );
  }
}
